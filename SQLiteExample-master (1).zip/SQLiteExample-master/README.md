# SQLiteExample
Hello Guys,In this 𝐚𝐧𝐝𝐫𝐨𝐢𝐝 𝐬𝐭𝐮𝐝𝐢𝐨 tutorial we will learn to  𝐢𝐧𝐬𝐞𝐫𝐭,𝐮𝐩𝐝𝐚𝐭𝐞,𝐝𝐞𝐥𝐞𝐭𝐞,𝐬𝐞𝐥𝐞𝐜𝐭 data in 𝐒𝐐𝐋𝐢𝐭𝐞 D𝐚𝐭𝐚𝐛𝐚𝐬𝐞.in this example we will store 𝐞𝐦𝐩𝐥𝐨𝐲𝐞𝐞  name,email in to 𝐒𝐐𝐋𝐢𝐭𝐞 D𝐚𝐭𝐚𝐛𝐚𝐬𝐞 and then select and modify data in 𝐒𝐐𝐋𝐢𝐭𝐞 D𝐚𝐭𝐚𝐛𝐚𝐬𝐞 in very simple way.

𝐒ᴜʙ𝐒ʀɪʙᴇ My 𝗬𝗢𝗨𝗧𝗨𝗕𝗘  Channel #𝗰𝗼𝗱𝗶𝗻𝗴𝘄𝗶𝘁𝗱𝗲𝘃 for more latest videos..
Watch Tutorial on -
[Youtube](https://youtu.be/BcpVlXo2F3U)


![GitHub Logo](/sqllite.png)
